﻿namespace PatsClothesShop {
    
    
    public partial class PatClothesShopDataSet {
    }
}

